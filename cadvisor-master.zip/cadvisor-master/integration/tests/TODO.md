Tests to Write:
- UI comes up
-- / -> /containers
-- /containers
-- /docker
- API tests
-- /containers
-- /subcontainers
